-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: based_clientes
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) DEFAULT NULL,
  `precio` double DEFAULT NULL,
  `horas` int DEFAULT NULL,
  `nivel` varchar(200) DEFAULT NULL,
  `profesor` varchar(200) DEFAULT NULL,
  `institucion` varchar(300) DEFAULT NULL,
  `fecha_inscripcion` date DEFAULT NULL,
  `fecha_inscripcionF` date DEFAULT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_cierre` date DEFAULT NULL,
  `num_Alumnos` varchar(45) DEFAULT NULL,
  `modalidad` varchar(45) DEFAULT NULL,
  `descripcion` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (18,'Base de Datos',45000,6,'Basico','Carlos Caceres','SENA','2023-04-12','2023-04-12','2023-04-12','2023-04-13','45','Presencial','Curso de base de datos apredices sena '),(19,'Pedro Martinez',45000,4,'medio','Jhon Arrieta','UDC','2023-04-13','2023-04-13','2023-04-13','2023-04-13','15','virtual','Clase magistral por estudiante Pedro Martinez / Curso de POO '),(20,'ggdfgdf',123,123,'1','F','SE','2023-06-07','2023-07-07','2023-06-14','2023-07-04','12','DSFDSF','FDSDFDSFDSF');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,'luis@gmail','123'),(2,'azucar@gmail.com','$2y$10$bK5hNdRk867j7rcHIt8i8ezwOiIydUlqpsiU/n1cl/BdjtfZkx29K'),(3,'fabiancho@gmail.com','$2y$10$Qh2sCW0Tj6OoMPhy0OEOPedAbYf9NhfuJpw0lShywy4GQxmilbB9K'),(4,'baron@gmail.com','$2y$10$BWWn5DNhlA8sF.5TBOdkSOF6eqcIlhuDxTQhbXpvD6CGrTKROfE6i'),(5,'jarrieta@gmail.com','$2y$10$RZUCFbcopw3PInpo7SrspuGIs6CgANQvhAXZL2rKPBK.r7MNc3ZBG'),(6,'david@correo.com','123'),(7,'fulanito@c','ghgfhjghjgkhg');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'based_clientes'
--

--
-- Dumping routines for database 'based_clientes'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-22 22:38:18
