package mvc.spring.boot.david.controlador;

import mvc.spring.boot.david.modelo.Cliente;
import mvc.spring.boot.david.services.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/clientes")
public class ClienteController {

    private final ClienteService clienteService;

    @Autowired
    public ClienteController(ClienteService clienteService) {
        this.clienteService = clienteService;
    }

    @GetMapping("/listar")
    public String listarClientes(Model model) {
        model.addAttribute("clientes", clienteService.listarClientes());
        return "Clientes/listar";
    }

    @GetMapping("/agregar")
    public String mostrarPlanillaAgregar(Model model) {
        model.addAttribute("cliente", new Cliente());
        return "Clientes/agregar";
    }

    @PostMapping("/agregar")
    public String agregarCliente(@ModelAttribute("cliente") Cliente cliente) {
        clienteService.guardarCliente(cliente);
        return "redirect:/clientes/listar";
    }

    @GetMapping("/editar/{id}")
    public String mostrarPlanillaEditar(@PathVariable("id") Long id, Model model) {
        Cliente cliente = clienteService.obtenerClientePorId(id)
                .orElseThrow(() -> new IllegalArgumentException("Cliente no encontrado con ID: " + id));
        model.addAttribute("cliente", cliente);
        return "Clientes/editar";
    }

    @PostMapping("/editar/{id}")
    public String editarCliente(@PathVariable("id") Long id, @ModelAttribute("cliente") Cliente cliente) {
        cliente.setId(id);
        clienteService.guardarCliente(cliente);
        return "redirect:/clientes/listar";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarCliente(@PathVariable("id") Long id) {
        clienteService.eliminarCliente(id);
        return "redirect:/clientes/listar";
    }
}
