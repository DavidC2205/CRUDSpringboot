package mvc.spring.boot.david.controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import mvc.spring.boot.david.modelo.Usuario;
import mvc.spring.boot.david.services.UsuarioService;

import java.util.Optional;

@Controller
@RequestMapping("/usuarios")
public class UsuarioController {

    private UsuarioService usuarioService;

    @Autowired
    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @GetMapping("/registro")
    public String mostrarPlanillaRegistro(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "Usuario/registrar";
    }

    @PostMapping("/registro")
    public String registrarUsuario(@ModelAttribute("usuario") Usuario usuario) {
        usuarioService.guardarUsuario(usuario);
        return "redirect:/usuarios/listar";
    }

    @GetMapping("/listar")
    public String listarUsuarios(Model model) {
        model.addAttribute("usuarios", usuarioService.obtenerTodosLosUsuarios());
        return "Usuario/listar";
    }

    @GetMapping("/editar/{id}")
    public String mostrarPlanillaEdicion(@PathVariable Long id, Model model) {
        Optional<Usuario> usuario = usuarioService.obtenerUsuarioPorId(id);
        if (usuario.isPresent()) {
            model.addAttribute("usuario", usuario.get());
            return "Usuario/editar";
        } else {
            return "redirect:/usuarios/listar";
        }
    }

    @PostMapping("/editar/{id}")
    public String editarUsuario(@PathVariable Long id, @ModelAttribute("usuario") Usuario usuario) {
        usuario.setId(id);
        usuarioService.guardarUsuario(usuario);
        return "redirect:/usuarios/listar";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarUsuario(@PathVariable Long id) {
        usuarioService.eliminarUsuarioPorId(id);
        return "redirect:/usuarios/listar";
    }

    @GetMapping("/login")
    public String mostrarPlanillaLogin(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "Usuario/login";
    }

    @PostMapping("/login")
    public String login(@ModelAttribute("usuario") Usuario usuario, Model model) {
        Usuario usuarioLogueado = usuarioService.login(usuario.getEmail(), usuario.getPassword());
        if (usuarioLogueado != null) {
            
            return "redirect:/usuarios/listar";
        } else {
            model.addAttribute("error", "Credenciales inválidas");
            return "Usuario/login";
        }
    }
}


