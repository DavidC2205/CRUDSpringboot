package mvc.spring.boot.david.modelo;

import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String nombre;
    private Double precio;
    private Integer horas;
    private String nivel;
    private String profesor;
    private String institucion;
    private Date fechaInscripcion;
    private Date fechaInscripcionF;
    private Date fechaInicio;
    private Date fechaCierre;
    private String numAlumnos;
    private String modalidad;
    private String descripcion;
    
    public Cliente() {
        // Constructor vacío necesario para JPA
    }
    
    // Constructor con todos los campos
    public Cliente(String nombre, Double precio, Integer horas, String nivel, String profesor, String institucion, 
                   Date fechaInscripcion, Date fechaInscripcionF, Date fechaInicio, Date fechaCierre, 
                   String numAlumnos, String modalidad, String descripcion) {
        this.nombre = nombre;
        this.precio = precio;
        this.horas = horas;
        this.nivel = nivel;
        this.profesor = profesor;
        this.institucion = institucion;
        this.fechaInscripcion = fechaInscripcion;
        this.fechaInscripcionF = fechaInscripcionF;
        this.fechaInicio = fechaInicio;
        this.fechaCierre = fechaCierre;
        this.numAlumnos = numAlumnos;
        this.modalidad = modalidad;
        this.descripcion = descripcion;
    }
    
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public Integer getHoras() {
        return horas;
    }

    public void setHoras(Integer horas) {
        this.horas = horas;
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    public String getProfesor() {
        return profesor;
    }

    public void setProfesor(String profesor) {
        this.profesor = profesor;
    }

    public String getInstitucion() {
        return institucion;
    }

    public void setInstitucion(String institucion) {
        this.institucion = institucion;
    }

    public Date getFechaInscripcion() {
        return fechaInscripcion;
    }

    public void setFechaInscripcion(Date fechaInscripcion) {
        this.fechaInscripcion = fechaInscripcion;
    }

    public Date getFechaInscripcionF() {
        return fechaInscripcionF;
    }

    public void setFechaInscripcionF(Date fechaInscripcionF) {
        this.fechaInscripcionF = fechaInscripcionF;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaCierre() {
        return fechaCierre;
    }

    public void setFechaCierre(Date fechaCierre) {
        this.fechaCierre = fechaCierre;
    }

    public String getNumAlumnos() {
        return numAlumnos;
    }

    public void setNumAlumnos(String numAlumnos) {
        this.numAlumnos = numAlumnos;
    }

    public String getModalidad() {
        return modalidad;
    }

    public void setModalidad(String modalidad) {
        this.modalidad = modalidad;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
